select
    category_id,
    name as category_name
from {{ source('dvdrental', 'category') }}
