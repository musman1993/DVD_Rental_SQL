select
    country_id,
    country
from {{ source('dvdrental', 'country') }}
