select
    staff_id,
    first_name,
    last_name,
    address_id,
    store_id,
    active as is_active
from {{ source('dvdrental', 'staff') }}
