select
    film_id,
    category_id
from {{ source('dvdrental', 'film_category') }}
