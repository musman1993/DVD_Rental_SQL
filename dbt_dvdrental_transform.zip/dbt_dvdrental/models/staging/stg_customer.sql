-- One row per customer, straight from the raw table with clearer column names.
select
    customer_id,
    store_id,
    first_name,
    last_name,
    email,
    address_id,
    activebool as is_active,
    create_date,
    last_update
from {{ source('dvdrental', 'customer') }}
