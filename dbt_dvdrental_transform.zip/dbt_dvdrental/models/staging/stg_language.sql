select
    language_id,
    trim(name) as language_name
from {{ source('dvdrental', 'language') }}
