-- Grain: one row per film.
-- film_category is many-to-many in the source (a film can technically have more
-- than one category), so we roll that up here rather than let it fan out fact_rental.

with film_categories as (

    select
        fc.film_id,
        min(cat.category_name) as primary_category,
        string_agg(cat.category_name, ', ' order by cat.category_name) as all_categories
    from {{ ref('stg_film_category') }} fc
    left join {{ ref('stg_category') }} cat on fc.category_id = cat.category_id
    group by fc.film_id

)

select
    f.film_id,
    f.title,
    f.description,
    f.release_year,
    l.language_name,
    f.rental_duration,
    f.rental_rate,
    f.length,
    f.replacement_cost,
    f.rating,
    fcat.primary_category as category,
    fcat.all_categories,
    f.special_features
from {{ ref('stg_film') }} f
left join {{ ref('stg_language') }} l on f.language_id = l.language_id
left join film_categories fcat on f.film_id = fcat.film_id
