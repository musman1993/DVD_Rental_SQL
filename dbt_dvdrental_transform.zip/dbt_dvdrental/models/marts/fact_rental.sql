-- Grain: one row per rental transaction (rental_id).
-- A rental can technically have more than one payment attached in the source data
-- (e.g. a late fee logged separately), so payments are pre-aggregated to keep
-- this at one row per rental rather than fanning out.

with payments_agg as (

    select
        rental_id,
        sum(amount) as revenue,
        count(payment_id) as payment_count
    from {{ ref('stg_payment') }}
    group by rental_id

)

select
    r.rental_id,
    r.customer_id,
    inv.film_id,
    inv.store_id,
    r.staff_id,
    r.rental_date::date as rental_date_day,
    r.return_date::date as return_date_day,
    r.rental_date,
    r.return_date,
    date_part('day', r.return_date - r.rental_date) as rental_duration_days,
    coalesce(p.revenue, 0) as revenue,
    coalesce(p.payment_count, 0) as payment_count
from {{ ref('stg_rental') }} r
left join {{ ref('stg_inventory') }} inv on r.inventory_id = inv.inventory_id
left join payments_agg p on r.rental_id = p.rental_id
