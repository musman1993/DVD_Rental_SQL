-- Grain: one row per calendar day.
-- Bounds are derived from the actual rental/return dates in the source data,
-- so this doesn't need to be hand-edited if the dataset changes.

with date_bounds as (

    select
        min(rental_date)::date as min_date,
        max(coalesce(return_date, rental_date))::date as max_date
    from {{ ref('stg_rental') }}

),

date_spine as (

    select generate_series(
        (select min_date from date_bounds),
        (select max_date from date_bounds),
        interval '1 day'
    )::date as date_day

)

select
    date_day,
    extract(year from date_day)::int as year,
    extract(quarter from date_day)::int as quarter,
    extract(month from date_day)::int as month,
    to_char(date_day, 'Month') as month_name,
    extract(day from date_day)::int as day_of_month,
    extract(dow from date_day)::int as day_of_week,
    to_char(date_day, 'Day') as day_name,
    extract(week from date_day)::int as week_of_year,
    (extract(dow from date_day) in (0, 6)) as is_weekend
from date_spine
