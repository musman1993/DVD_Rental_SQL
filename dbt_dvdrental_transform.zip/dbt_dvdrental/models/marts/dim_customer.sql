-- Grain: one row per customer.
-- Enriches the raw customer record with their address, city, and country
-- so downstream BI tools don't need to re-join four tables for a "customer by country" chart.

select
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.is_active,
    c.store_id,
    a.address,
    a.district,
    ci.city,
    co.country,
    c.create_date
from {{ ref('stg_customer') }} c
left join {{ ref('stg_address') }} a on c.address_id = a.address_id
left join {{ ref('stg_city') }} ci on a.city_id = ci.city_id
left join {{ ref('stg_country') }} co on ci.country_id = co.country_id
