-- dbt convention: a singular test should return zero rows to pass.
-- This fails the build if any rental somehow has negative revenue.

select
    rental_id,
    revenue
from {{ ref('fact_rental') }}
where revenue < 0
