# dvdrental_analytics — dbt transformation layer

Turns the raw `dvdrental` Postgres tables into a proper star schema:

```
public (raw)  →  staging (views, 1:1 renamed)  →  marts (star schema, tables)
```

## Star schema

```
                dim_customer
                     |
dim_date  ──  fact_rental  ──  dim_film
                (1 row per rental)
```

- **fact_rental** — grain is one row per `rental_id`. Payments are pre-aggregated
  to this grain (a rental can have more than one payment, e.g. a late fee).
- **dim_customer** — one row per customer, joined out to address/city/country.
- **dim_film** — one row per film, joined out to language and category
  (category is many-to-many in the source; rolled up here so it doesn't fan out the fact table).
- **dim_date** — a generated date spine, bounded dynamically by the actual rental
  date range in the data (not hardcoded).

## Setup

1. Install dbt with the Postgres adapter:
   ```bash
   pip install dbt-postgres
   ```
2. Copy `profiles.yml.example` to `~/.dbt/profiles.yml`.
3. Make sure your Postgres container is running (`make run` from the repo root).
4. From this folder:
   ```bash
   dbt deps      # installs dbt_utils
   dbt run       # builds staging views + mart tables
   dbt test      # runs all schema + singular tests
   dbt docs generate && dbt docs serve   # browsable lineage graph + column docs
   ```

## Folder structure

```
models/
  staging/     -- thin, renamed views over each raw table + sources.yml
  marts/       -- the star schema (fact_rental, dim_customer, dim_film, dim_date)
macros/        -- generate_schema_name.sql (keeps schema naming simple)
tests/         -- singular tests (business-rule checks beyond generic not_null/unique)
```

## Where this plugs into the rest of the project

Point `app.py` (or the future Superset/ClickHouse layer) at the `analytics_marts`
schema instead of raw `public` tables — you get pre-joined, tested, documented
tables instead of re-deriving revenue/category joins in every query.
